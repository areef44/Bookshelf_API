/**
 * 1.Buat db untuk meyimpan data
 */

const books = [];
 
/**
 * 2.export db agar bisa digunakan di handler
 */

module.exports = books;